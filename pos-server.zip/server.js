// الكاشير الذكي v2 - نظام شركات متعددة. بدون مكتبات خارجية (Node 18+)
const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const PORT=process.env.PORT||3000,DIR=process.env.DATA_DIR||__dirname,FILE=path.join(DIR,"data.json");
const AK=process.env.ADMIN_KEY||"",AP=(process.env.ADMIN_PHONE||"").replace(/\D/g,"");
let D={cos:{},tokens:{}};try{D={...D,...JSON.parse(fs.readFileSync(FILE,"utf8"))}}catch(e){}
function persist(C){if(C)C.v++;fs.mkdirSync(DIR,{recursive:true});const t=FILE+".tmp";fs.writeFileSync(t,JSON.stringify(D));fs.renameSync(t,FILE)}
const sh=(p,s)=>crypto.scryptSync(String(p),s,32).toString("hex");
const mk=p=>{const s=crypto.randomBytes(16).toString("hex");return s+":"+sh(p,s)};
const ck=(p,st)=>{const[s,h]=String(st||"").split(":");if(!h)return false;const a=Buffer.from(sh(p,s)),b=Buffer.from(h);return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const h256=p=>crypto.createHash("sha256").update("pos:"+p).digest("hex");
const S_=(v,n=100)=>String(v??"").slice(0,n),dig=v=>S_(v,20).replace(/\D/g,"");
const fails={};const limited=k=>{const f=fails[k];return f&&f.n>=10&&Date.now()-f.t<6e5};
const fail=k=>{const f=fails[k]=fails[k]&&Date.now()-fails[k].t<6e5?fails[k]:{n:0,t:Date.now()};f.n++};
function state(C,u){const mg=u.role!=="cashier";return{v:C.v,me:{name:u.name,role:u.role},co:C.name,cur:C.cur,tax:C.tax,cc:C.cc,
 users:u.role==="owner"?C.users.map(x=>({name:x.name,role:x.role,phone:x.phone})):[{name:u.name,role:u.role,phone:u.phone}],
 cats:C.cats,prods:mg?C.prods:C.prods.map(({cost,...p})=>p),custs:C.custs,sales:mg?C.sales.slice(-3000):[],counts:mg?C.counts.slice(-20):[]}}
function auth(req){const t=(req.headers.authorization||"").replace("Bearer ","");const k=D.tokens[t];if(!k||k.exp<Date.now())return null;const C=D.cos[k.co];if(!C||!C.active)return null;const u=C.users.find(x=>x.name===k.name);return u?{C,u}:null}
function newTok(co,name){const t=crypto.randomBytes(32).toString("hex");D.tokens[t]={co,name,exp:Date.now()+30*864e5};for(const x in D.tokens)if(D.tokens[x].exp<Date.now())delete D.tokens[x];return t}
const revoke=(co,name)=>{for(const t in D.tokens){const k=D.tokens[t];if(k.co===co&&(!name||k.name===name))delete D.tokens[t]}};
const send=(res,c,o)=>{res.writeHead(c,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});res.end(JSON.stringify(o))};
const body=req=>new Promise((ok,no)=>{let b="";req.on("data",c=>{b+=c;if(b.length>5e6){no();req.destroy()}});req.on("end",()=>{try{ok(JSON.parse(b||"{}"))}catch(e){no(e)}})});
const upCust=(C,phone,name)=>{if(!phone)return;const c=C.custs.find(x=>x.phone===phone);c?(c.name=name||c.name):C.custs.push({phone,name:name||""})};
const codeGen=()=>{const a="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";for(const b of crypto.randomBytes(6))s+=a[b%a.length];return s};
const mkUser=(name,role,phone,passHash)=>({name:S_(name,40).trim(),role,phone:dig(phone),pw:mk(passHash)});
const routes={
 /* ---- عام ---- */
 "GET /api/contact":async(req,res,b,ip,x,q)=>{const C=D.cos[S_(q.get("co"),12).toUpperCase()],n=S_(q.get("name"),40).toLowerCase();if(!C)return[404,{error:"كود الشركة غير صحيح"}];
  const u=C.users.find(z=>z.name.toLowerCase()===n);if(!u)return[404,{error:"المستخدم غير موجود"}];const ph=u.role==="owner"?AP:(C.users.find(z=>z.role==="owner")||{}).phone;
  return ph?[200,{phone:ph}]:[404,{error:"لا يوجد رقم تواصل مسجّل"}]},
 "POST /api/login":async(req,res,b,ip)=>{const co=S_(b.co,12).trim().toUpperCase(),k=ip+co;if(limited(k))return[429,{error:"محاولات كثيرة، انتظر عدة دقائق"}];
  const C=D.cos[co],n=S_(b.name,40).trim().toLowerCase(),u=C&&C.users.find(z=>z.name.toLowerCase()===n);
  if(!u||!ck(b.pass,u.pw)){fail(k);return[401,{error:"كود الشركة أو اسم المستخدم أو كلمة السر غير صحيحة"}]}
  if(!C.active)return[403,{error:"الاشتراك موقوف، تواصل مع الإدارة"}];delete fails[k];const t=newTok(co,u.name);persist();return[200,{token:t,state:state(C,u)}]},
 /* ---- المستخدم المسجّل ---- */
 "GET /api/state":async(req,res,b,ip,{C,u})=>[200,{state:state(C,u)}],
 "POST /api/sale":async(req,res,b,ip,{C,u})=>{const it=[];let sub=0;
  for(const r of Array.isArray(b.items)?b.items:[]){const p=C.prods.find(z=>z.bc===r.bc),q=Math.floor(+r.q);if(!p||!(q>0))return[400,{error:"صنف غير صالح"}];if(q>p.qty)return[400,{error:"نفد المخزون: "+p.name}];it.push({p,q})}
  if(!it.length)return[400,{error:"السلة فارغة"}];
  const rows=it.map(({p,q})=>{p.qty-=q;sub+=p.price*q;return{n:p.name,q,pr:p.price,c:p.cost||0}});
  const d=Math.min(Math.max(+b.disc||0,0),sub),tax=(sub-d)*C.tax/100,ph=dig(b.cust&&b.cust.phone),nm=S_(b.cust&&b.cust.name,60);
  upCust(C,ph,nm);const s={id:++C.seq,t:Date.now(),by:u.name,cust:{name:nm,phone:ph},items:rows,sub,disc:d,tax,tot:sub-d+tax,pay:S_(b.pay,20)};
  C.sales.push(s);persist(C);const out=u.role==="cashier"?{...s,items:rows.map(({c,...r})=>r)}:s;return[200,{sale:out,state:state(C,u)}]},
 "POST /api/ai":async(req,res,b)=>{const k=process.env.ANTHROPIC_API_KEY;if(!k)return[503,{error:"الذكاء الاصطناعي غير مفعّل"}];const pr=S_(b.prompt,8000);if(!pr)return[400,{error:"طلب فارغ"}];
  try{const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"x-api-key":k,"anthropic-version":"2023-06-01","content-type":"application/json"},body:JSON.stringify({model:process.env.AI_MODEL||"claude-haiku-5-5",max_tokens:700,messages:[{role:"user",content:pr}]})});
   const j=await r.json();if(!r.ok)return[502,{error:"تعذر الاتصال بالذكاء الاصطناعي"}];return[200,{text:(j.content||[]).map(c=>c.text||"").join("")}]}catch(e){return[502,{error:"تعذر الاتصال بالذكاء الاصطناعي"}]}},
 "POST /api/sync":async(req,res,b,ip,{C,u})=>{if(u.role==="cashier")return[403,{error:"غير مسموح"}];const own=u.role==="owner";
  if(Array.isArray(b.cats)){const n=b.cats.map(c=>S_(c,40)).filter(Boolean);C.cats=[...new Set(own?n:[...C.cats,...n])]}
  if(Array.isArray(b.prods)){const old=new Map(C.prods.map(p=>[p.bc,p])),seen=new Set();
   const np=b.prods.filter(p=>p&&p.bc&&p.name).map(p=>{const bc=S_(p.bc,60),o=old.get(bc);seen.add(bc);return{bc,name:S_(p.name,100),price:Math.max(0,+p.price||0),cost:Math.max(0,+p.cost||0),qty:o&&!p._q?o.qty:Math.max(0,Math.floor(+p.qty||0)),cat:S_(p.cat,40),sup:S_(p.sup,60),desc:S_(p.desc,500)}});
   C.prods=own?np:[...np,...C.prods.filter(p=>!seen.has(p.bc))]}   // الحذف للمالك فقط
  if(Array.isArray(b.custs)){const inc=b.custs.filter(c=>c&&c.phone).map(c=>({phone:dig(c.phone),name:S_(c.name,60)}));
   if(own)C.custs=inc;else{const m=new Map(C.custs.map(c=>[c.phone,c]));inc.forEach(c=>m.set(c.phone,c));C.custs=[...m.values()]}}
  if(own){if(b.co)C.name=S_(b.co,60);if(b.cur!==undefined)C.cur=S_(b.cur,10);if(b.tax!==undefined)C.tax=Math.min(100,Math.max(0,+b.tax||0));if(b.cc)C.cc=dig(b.cc)||"20";
   if(Array.isArray(b.users)){const old=new Map(C.users.map(z=>[z.name,z]));
    const nu=b.users.filter(z=>z&&z.name&&["owner","manager","cashier"].includes(z.role)).map(z=>{const o=old.get(z.name);return{name:S_(z.name,40),role:o?o.role:(z.role==="owner"?"manager":z.role),phone:dig(z.phone),pw:z.pass?mk(z.pass):(o?o.pw:null),chg:!!z.pass}}).filter(z=>z.pw);
    if(nu.some(z=>z.role==="owner")){for(const t in D.tokens){const k=D.tokens[t];if(k.co!==C.code)continue;const z=nu.find(y=>y.name===k.name);if(!z||(z.chg&&z.name!==u.name))delete D.tokens[t]}C.users=nu.map(({chg,...r})=>r)}}}
  persist(C);return[200,{state:state(C,C.users.find(z=>z.name===u.name)||u)}]},
 "POST /api/stocktake":async(req,res,b,ip,{C,u})=>{if(u.role==="cashier")return[403,{error:"غير مسموح"}];const items=[];
  for(const r of Array.isArray(b.counts)?b.counts:[]){const p=C.prods.find(z=>z.bc===r.bc),a=Math.floor(+r.actual);if(!p||!(a>=0))continue;items.push({bc:p.bc,n:p.name,sys:p.qty,act:a,diff:a-p.qty,cost:p.cost||0});p.qty=a}
  if(!items.length)return[400,{error:"لا توجد كميات صالحة"}];const rec={id:C.counts.length+1,t:Date.now(),by:u.name,items};C.counts.push(rec);persist(C);return[200,{count:rec,state:state(C,u)}]},
 /* ---- لوحة إدارة النظام (أنت) ---- */
 "GET /api/admin/list":async()=>[200,{cos:Object.values(D.cos).map(C=>({code:C.code,name:C.name,active:C.active,users:C.users.length,sales:C.sales.length,owner:(C.users.find(u=>u.role==="owner")||{}).name,created:C.created}))}],
 "POST /api/admin/create":async(req,res,b)=>{const name=S_(b.name,60).trim(),on=S_(b.ownerName,40).trim(),pw=S_(b.pass,60);if(!name||!on||pw.length<6)return[400,{error:"أكمل البيانات (كلمة السر 6 أحرف+)"}];
  let code=S_(b.code,12).toUpperCase().replace(/[^A-Z0-9]/g,"")||codeGen();if(D.cos[code])return[409,{error:"الكود مستخدم"}];
  D.cos[code]={code,name,cur:S_(b.cur,10)||"ج.م",tax:0,cc:"20",active:true,created:Date.now(),users:[mkUser(on,"owner",b.phone,h256(pw))],cats:["عام"],prods:[],custs:[],sales:[],counts:[],seq:0,v:1};
  persist();return[200,{code,owner:on}]},
 "POST /api/admin/active":async(req,res,b)=>{const C=D.cos[S_(b.code,12)];if(!C)return[404,{error:"غير موجود"}];C.active=!!b.active;if(!C.active)revoke(C.code);persist();return[200,{}]},
 "POST /api/admin/resetpw":async(req,res,b)=>{const C=D.cos[S_(b.code,12)],pw=S_(b.pass,60);const u=C&&C.users.find(z=>z.name===b.name);if(!u||pw.length<6)return[400,{error:"بيانات غير صحيحة"}];u.pw=mk(h256(pw));revoke(C.code,u.name);persist();return[200,{}]}
};
const isAdmin=req=>{if(!AK)return null;const k=String(req.headers["x-admin-key"]||"");const a=crypto.createHash("sha256").update(k).digest(),b=crypto.createHash("sha256").update(AK).digest();return crypto.timingSafeEqual(a,b)};
const PUB=path.join(__dirname,"public");
http.createServer(async(req,res)=>{
 try{const U=new URL(req.url,"http://x"),url=U.pathname,ip=(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"").split(",")[0].trim(),key=req.method+" "+url;
  if(url.startsWith("/api/")){const h=routes[key];if(!h)return send(res,404,{error:"غير موجود"});let x=null;
   if(url.startsWith("/api/admin/")){const a=isAdmin(req);if(a===null)return send(res,503,{error:"ADMIN_KEY غير مضبوط على السيرفر"});if(!a)return send(res,401,{error:"مفتاح الإدارة غير صحيح"})}
   else if(key!=="POST /api/login"&&key!=="GET /api/contact"){x=auth(req);if(!x)return send(res,401,{error:"سجّل الدخول"})}
   const b=req.method==="POST"?await body(req):{};const[c,o]=await h(req,res,b,ip,x,U.searchParams);return send(res,c,o)}
  if(req.method!=="GET")return send(res,405,{});
  const f=path.join(PUB,url==="/"?"index.html":path.normalize(url).replace(/^(\.\.[\/\\])+/,""));
  if(!f.startsWith(PUB)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);return res.end("404")}
  const ty={".html":"text/html; charset=utf-8",".js":"text/javascript",".css":"text/css",".png":"image/png",".json":"application/json"}[path.extname(f)]||"application/octet-stream";
  res.writeHead(200,{"Content-Type":ty,"X-Content-Type-Options":"nosniff","Referrer-Policy":"same-origin","Permissions-Policy":"camera=(self)"});fs.createReadStream(f).pipe(res);
 }catch(e){send(res,400,{error:"طلب غير صالح"})}
}).listen(PORT,()=>console.log("الكاشير الذكي يعمل على المنفذ "+PORT+(AK?"":" — تنبيه: ADMIN_KEY غير مضبوط")));
